﻿# reconcile_reply.ps1 — 對帳單回覆登錄
# 用法:
#   .\reconcile_reply.ps1 -List                               (列出所有回覆)
#   .\reconcile_reply.ps1 -Find ACCNO                         (查詢特定帳號回覆)
#   .\reconcile_reply.ps1 -FilterYearMonth 11305              (依年月篩選)
#   .\reconcile_reply.ps1 -Register ACCNO -YearMonth 11305    (登錄回覆)
#   .\reconcile_reply.ps1 -CubPassword <密碼>

param(
    [string]$CubPath = "",
    [switch]$List,
    [string]$Find = "",
    [string]$FilterYearMonth = "",
    [string]$Register = "",
    [string]$YearMonth = "",
    [string]$CubPassword = ""
)

Set-Location (Split-Path -Parent $MyInvocation.MyCommand.Path)

if ([string]::IsNullOrEmpty($CubPassword)) {
    Write-Host "════════════════════════════════════════════════════════════════════════════════════" -ForegroundColor Yellow
    Write-Host "║   CUB.MDB 需要密碼                                          ║" -ForegroundColor Yellow
    Write-Host "════════════════════════════════════════════════════════════════════════════════════" -ForegroundColor Yellow
    $secure = Read-Host -Prompt "  請輸入 CUB.MDB 密碼" -AsSecureString
    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $CubPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($ptr) } finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) | Out-Null }
    Write-Host ""
}

$daoAvailable = $false
try { $null = New-Object -ComObject DAO.DBEngine.120; $daoAvailable = $true } catch {}

if (-not $daoAvailable -and -not $env:DAO_RESTARTED) {
    $ps32 = "$env:SystemRoot\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
    if (Test-Path $ps32) {
        Write-Host "  偵測到 32-bit 需求，自動切換..." -ForegroundColor Yellow
        $env:DAO_RESTARTED = '1'
        $argList = @()
        if ($CubPath -ne '') { $argList += '-CubPath', $CubPath }
        if ($List) { $argList += '-List' }
        if ($Find) { $argList += '-Find', $Find }
        if ($FilterYearMonth) { $argList += '-FilterYearMonth', $FilterYearMonth }
        if ($Register) { $argList += '-Register', $Register }
        if ($YearMonth) { $argList += '-YearMonth', $YearMonth }
        if ($CubPassword -ne '') { $argList += '-CubPassword', $CubPassword }
        & $ps32 -ExecutionPolicy Bypass -File "`"$PSCommandPath`"" @argList
        exit $LASTEXITCODE
    }
}

if (-not $daoAvailable) {
    Write-Host "  DAO.DBEngine 無法初始化，請安裝 Access Database Engine 2016" -ForegroundColor Red
    exit 1
}

if ([string]::IsNullOrEmpty($CubPath)) { $CubPath = Join-Path $PSScriptRoot "CUB.MDB" }
$CubPath = [System.IO.Path]::GetFullPath($CubPath)
if (-not (Test-Path $CubPath)) { Write-Host "  找不到 CUB.MDB: $CubPath" -ForegroundColor Red; exit 1 }

$connectStr = ";PWD=$CubPassword"

try {
    $dbe = New-Object -ComObject DAO.DBEngine.120
    $needWrite = ($Register -ne "")
    $db = $dbe.OpenDatabase($CubPath, $false, (-not $needWrite), $connectStr)

    # 檢查 k_對帳單回覆 是否存在，若不存在則建立（需可寫入）
    $hasTable = @($db.TableDefs | Where-Object { $_.Name -eq "k_對帳單回覆" }).Count -gt 0
    if (-not $hasTable) {
        if (-not $needWrite) { $db.Close(); $db = $dbe.OpenDatabase($CubPath, $false, $false, $connectStr); $needWrite = $true }
        Write-Host "  k_對帳單回覆 不存在於 CUB.MDB，嘗試建立..." -ForegroundColor Yellow
        try {
            $td = $db.CreateTableDef("k_對帳單回覆")
            $td.Fields.Append($td.CreateField("年月", 10, 6))
            $td.Fields.Append($td.CreateField("科目", 10, 6))
            $td.Fields.Append($td.CreateField("帳號", 10, 6))
            $td.Fields.Append($td.CreateField("戶名", 10, 10))
            $td.Fields.Append($td.CreateField("回覆日期", 8))
            $td.Fields.Append($td.CreateField("備註", 10, 50))
            $db.TableDefs.Append($td)
            Write-Host "  已建立 k_對帳單回覆 表" -ForegroundColor Green
        }
        catch {
            Write-Host "  無法建立 k_對帳單回覆: $_" -ForegroundColor Red
            $db.Close(); exit 1
        }
    }
    # 若 Register 需要寫入但當前是唯讀，重新開啟
    if ($Register -ne "" -and -not $needWrite) {
        $db.Close(); $db = $dbe.OpenDatabase($CubPath, $false, $false, $connectStr)
    }

    $whereClauses = @()
    $params = @{}
    if ($FilterYearMonth -ne "") {
        $whereClauses += "年月=[p_ym]"
        $params["p_ym"] = $FilterYearMonth
    }
    if ($Find -ne "") {
        $padded = Pad-Account $Find
        $whereClauses += "帳號=[p_acc]"
        $params["p_acc"] = $padded
    }

    $sql = "SELECT * FROM [k_對帳單回覆]"
    if ($whereClauses.Count -gt 0) {
        $sql += " WHERE " + ($whereClauses -join " AND ")
    }
    $sql += " ORDER BY 年月, 帳號"

    $qdef = $db.CreateQueryDef("", $sql)
    foreach ($k in $params.Keys) { $qdef.Parameters($k).Value = $params[$k] }
    $rs = $qdef.OpenRecordset()
    Write-Host "`n=== 對帳單回覆清單 ===" -ForegroundColor Cyan
    $count = 0
    while (-not $rs.EOF) {
        $ym = if ($rs.Fields("年月").Value) { $rs.Fields("年月").Value } else { "" }
        $acc = if ($rs.Fields("帳號").Value) { $rs.Fields("帳號").Value } else { "" }
        $name = if ($rs.Fields("戶名").Value) { $rs.Fields("戶名").Value } else { "" }
        $rdate = if ($rs.Fields("回覆日期").Value) { $rs.Fields("回覆日期").Value } else { "" }
        $memo = if ($rs.Fields("備註").Value) { $rs.Fields("備註").Value } else { "" }
        Write-Host ("  {0,-8} {1,-8} {2,-10} {3,-12} {4}" -f $ym, $acc, $name, $rdate, $memo)
        $count++
        $rs.MoveNext()
    }
    $rs.Close()
    Write-Host "  共 $count 筆" -ForegroundColor Green

    # 登錄新回覆
    if ($Register -ne "") {
        $ym = if ($YearMonth -ne "") { $YearMonth } else { (Get-Date).ToString("yyyMM") }
        $padded = Pad-Account $Register
        $today = (Get-Date).ToString("yyyy/MM/dd")

        # 查戶名
        $qdef = $db.CreateQueryDef("", "SELECT ACCNM FROM SER WHERE (OUTDAT IS NULL OR OUTDAT='') AND ACCNO=[p_acc]")
        $qdef.Parameters("p_acc").Value = $padded
        $rs2 = $qdef.OpenRecordset()
        $name = if (-not $rs2.EOF) { $rs2.Fields("ACCNM").Value } else { "" }
        $rs2.Close()

        $qdef = $db.CreateQueryDef("", "SELECT * FROM [k_對帳單回覆] WHERE 年月=[p_ym] AND 帳號=[p_acc]")
        $qdef.Parameters("p_ym").Value = $ym
        $qdef.Parameters("p_acc").Value = $padded
        $rs2 = $qdef.OpenRecordset()
        if ($rs2.EOF) {
            $rs2.AddNew()
            $rs2.Fields("年月").Value = $ym
            $rs2.Fields("科目").Value = ""
            $rs2.Fields("帳號").Value = $padded
            $rs2.Fields("戶名").Value = $name
            $rs2.Fields("回覆日期").Value = $today
            $rs2.Fields("備註").Value = ""
            $rs2.Update()
            Write-Host "  已登錄回覆: $padded ($name) 於 $ym" -ForegroundColor Green
        }
        else {
            Write-Host "  此筆已存在: $padded 於 $ym" -ForegroundColor Yellow
        }
        $rs2.Close()
    }

    $db.Close()
}
catch {
    Write-Host "  錯誤: $_" -ForegroundColor Red
}
finally {
    if ($dbe) { [Runtime.InteropServices.Marshal]::ReleaseComObject($dbe) | Out-Null }
}

function Pad-Account {
    param([string]$Acc)
    if ([string]::IsNullOrEmpty($Acc)) { return $Acc }
    return $Acc.PadLeft(6, '0')
}

if (-not $List -and $Find -eq "" -and $FilterYearMonth -eq "" -and $Register -eq "") {
    Write-Host "`n用法:" -ForegroundColor Yellow
    Write-Host "  .\reconcile_reply.ps1 -List                        列出所有回覆" -ForegroundColor DarkGray
    Write-Host "  .\reconcile_reply.ps1 -Find ACCNO                  查詢特定帳號" -ForegroundColor DarkGray
    Write-Host "  .\reconcile_reply.ps1 -FilterYearMonth 11305       依年月篩選" -ForegroundColor DarkGray
    Write-Host "  .\reconcile_reply.ps1 -Register ACCNO -YearMonth 11305  登錄回覆" -ForegroundColor DarkGray
    Write-Host "`n按任意鍵結束..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

